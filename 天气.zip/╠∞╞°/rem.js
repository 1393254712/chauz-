(function () {
    (function () {
        var html = document.getElementsByTagName('html')[0];
        var w = window.innerWidth / 3.75;
        html.style.fontSize = w + "px";
    }())
}())